package com.freetime.geoweather

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.freetime.geoweather.ui.theme.GeoWeatherTheme

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import com.freetime.geoweather.data.LocationDatabase
import com.freetime.geoweather.data.LocationEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter

class SettingsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        hideSystemBars()
        
        setContent {
            val sharedPreferences = remember { getSharedPreferences("geo_weather_prefs", Context.MODE_PRIVATE) }
            val useSystemTheme = sharedPreferences.collectAsState(key = "use_system_theme", defaultValue = true)
            val darkModeEnabled = sharedPreferences.collectAsState(key = "dark_mode_enabled", defaultValue = false)
            val dynamicColor = sharedPreferences.collectAsState(key = "dynamic_color", defaultValue = true)
            val oledBlackState = sharedPreferences.collectAsState(key = "oled_black", defaultValue = false)

            val darkTheme = if (useSystemTheme.value) isSystemInDarkTheme() else darkModeEnabled.value
            
            GeoWeatherTheme(darkTheme = darkTheme, dynamicColor = dynamicColor.value, oledBlack = oledBlackState.value) {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    SettingsScreen(
                        modifier = Modifier.padding(innerPadding),
                        onBack = { finish() }
                    )
                }
            }
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            hideSystemBars()
        }
    }

    private fun hideSystemBars() {
        val windowInsetsController =
            WindowCompat.getInsetsController(window, window.decorView)
        windowInsetsController.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        windowInsetsController.hide(WindowInsetsCompat.Type.systemBars())
    }
}

@SuppressLint("ApplySharedPref")
@Composable
fun SettingsScreen(modifier: Modifier = Modifier, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val sharedPreferences = remember { 
        context.getSharedPreferences("geo_weather_prefs", Context.MODE_PRIVATE) 
    }
    val db = remember { LocationDatabase.getDatabase(context) }

    val exportSuccess = stringResource(R.string.export_success)
    val exportFailed = stringResource(R.string.export_failed)
    val importSuccess = stringResource(R.string.import_success)
    val importFailed = stringResource(R.string.import_failed)
    val feedbackSubject = stringResource(R.string.feedback_subject)

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            scope.launch(Dispatchers.IO) {
                try {
                    val locations = db.locationDao().getAllLocationsSync()
                    val root = JSONObject()
                    val array = JSONArray()
                    locations.forEach { loc ->
                        val obj = JSONObject()
                        obj.put("name", loc.name)
                        obj.put("lat", loc.latitude)
                        obj.put("lon", loc.longitude)
                        obj.put("notif_enabled", loc.notificationsEnabled)
                        obj.put("notif_time", loc.notificationTime)
                        obj.put("alert_enabled", loc.changeAlertsEnabled)
                        obj.put("alert_interval", loc.changeAlertInterval)
                        obj.put("is_default", loc.isDefault)
                        array.put(obj)
                    }
                    root.put("locations", array)
                    root.put("version", 1)

                    context.contentResolver.openOutputStream(uri)?.use { os ->
                        OutputStreamWriter(os).use { writer ->
                            writer.write(root.toString(4))
                        }
                    }
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, exportSuccess, Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "$exportFailed: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch(Dispatchers.IO) {
                try {
                    context.contentResolver.openInputStream(uri)?.use { inputStream ->
                        val reader = BufferedReader(InputStreamReader(inputStream))
                        val content = reader.readText()
                        val root = JSONObject(content)
                        val array = root.getJSONArray("locations")
                        
                        for (i in 0 until array.length()) {
                            val obj = array.getJSONObject(i)
                            val lat = obj.getDouble("lat")
                            val lon = obj.getDouble("lon")
                            
                            val existing = db.locationDao().findByCoordinates(lat, lon)
                            if (existing == null) {
                                db.locationDao().insertLocation(LocationEntity(
                                    name = obj.getString("name"),
                                    latitude = lat,
                                    longitude = lon,
                                    notificationsEnabled = obj.optBoolean("notif_enabled", false),
                                    notificationTime = obj.optString("notif_time", "08:00"),
                                    changeAlertsEnabled = obj.optBoolean("alert_enabled", false),
                                    changeAlertInterval = obj.optString("alert_interval", "3"),
                                    isDefault = obj.optBoolean("is_default", false)
                                ))
                            }
                        }
                    }
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, importSuccess, Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "$importFailed: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }
    
    var darkModeEnabled by remember {
        mutableStateOf(sharedPreferences.getBoolean("dark_mode_enabled", false))
    }
    
    var useSystemTheme by remember {
        mutableStateOf(sharedPreferences.getBoolean("use_system_theme", true))
    }

    var dynamicColor by remember {
        mutableStateOf(sharedPreferences.getBoolean("dynamic_color", true))
    }

    var oledBlack by remember {
        mutableStateOf(sharedPreferences.getBoolean("oled_black", false))
    }

    var disablePrivateView by remember {
        mutableStateOf(sharedPreferences.getBoolean("disable_private_view", false))
    }

    var openExternalBrowser by remember {
        mutableStateOf(sharedPreferences.getBoolean("open_external_browser", false))
    }

    val tempUnitState by sharedPreferences.collectStringAsState("temp_unit", "celsius")
    var tempUnit by remember { mutableStateOf(tempUnitState) }
    LaunchedEffect(tempUnitState) { tempUnit = tempUnitState }

    val windUnitState by sharedPreferences.collectStringAsState("wind_unit", "kmh")
    var windUnit by remember { mutableStateOf(windUnitState) }
    LaunchedEffect(windUnitState) { windUnit = windUnitState }

    val pressureUnitState by sharedPreferences.collectStringAsState("pressure_unit", "hpa")
    var pressureUnit by remember { mutableStateOf(pressureUnitState) }
    LaunchedEffect(pressureUnitState) { pressureUnit = pressureUnitState }

    var tempThreshold by remember {
        mutableStateOf(sharedPreferences.getInt("notif_temp_threshold", 5))
    }

    var windThreshold by remember {
        mutableStateOf(sharedPreferences.getInt("notif_wind_threshold", 15))
    }

    var persistentNotif by remember {
        mutableStateOf(sharedPreferences.getBoolean("persistent_notif", false))
    }

    val currentAppLocale = remember {
        AppCompatDelegate.getApplicationLocales().toLanguageTags().ifEmpty { "system" }
    }
    var appLanguage by remember { mutableStateOf(currentAppLocale) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Bar area
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilledTonalButton(onClick = onBack) {
                Text(stringResource(R.string.back_btn))
            }

            FilledTonalButton(onClick = {
                context.startActivity(Intent(context, ChangeLogActivity::class.java))
            }) {
                Text(stringResource(R.string.open_change_log))
            }
        }
        
        Text(
            text = stringResource(R.string.theme_settings_title),
            style = MaterialTheme.typography.headlineSmall
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                SettingsToggle(
                    title = stringResource(R.string.dynamic_color_title),
                    subtitle = stringResource(R.string.dynamic_color_subtitle),
                    checked = dynamicColor,
                    onCheckedChange = {
                        dynamicColor = it
                        sharedPreferences.edit().putBoolean("dynamic_color", it).apply()
                    }
                )

                SettingsToggle(
                    title = stringResource(R.string.oled_black_title),
                    subtitle = stringResource(R.string.oled_black_subtitle),
                    checked = oledBlack,
                    onCheckedChange = {
                        oledBlack = it
                        sharedPreferences.edit().putBoolean("oled_black", it).apply()
                    }
                )

                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                SettingsToggle(
                    title = stringResource(R.string.follow_system_theme),
                    checked = useSystemTheme,
                    onCheckedChange = {
                        useSystemTheme = it
                        sharedPreferences.edit().putBoolean("use_system_theme", it).apply()
                    }
                )

                SettingsToggle(
                    title = stringResource(R.string.force_dark_mode),
                    subtitle = stringResource(R.string.override_system_setting),
                    checked = darkModeEnabled,
                    enabled = !useSystemTheme,
                    onCheckedChange = {
                        darkModeEnabled = it
                        sharedPreferences.edit().putBoolean("dark_mode_enabled", it).apply()
                    }
                )
            }
        }

        Text(
            text = stringResource(R.string.language_settings_title),
            style = MaterialTheme.typography.headlineSmall
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                val currentLangLabel = when (appLanguage) {
                    "system", "" -> stringResource(R.string.lang_system)
                    "en" -> stringResource(R.string.lang_en)
                    "ru" -> stringResource(R.string.lang_ru)
                    "de" -> stringResource(R.string.lang_de)
                    "es" -> "Español"
                    "fr" -> "Français"
                    "it" -> "Italiano"
                    "zh" -> "中文"
                    "ja" -> "日本語"
                    "ko" -> "한국어"
                    "pt" -> "Português"
                    "nl" -> "Nederlands"
                    "pl" -> "Polski"
                    "tr" -> "Türkçe"
                    "cs" -> "Čeština"
                    "uk" -> "Українська"
                    "ar" -> "العربية"
                    else -> appLanguage
                }

                Text(stringResource(R.string.select_language), style = MaterialTheme.typography.bodyLarge)
                
                Button(
                    onClick = { 
                        context.startActivity(Intent(context, LanguageSettingsActivity::class.java))
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(currentLangLabel)
                }
            }
        }

        Text(
            text = stringResource(R.string.unit_settings_title),
            style = MaterialTheme.typography.headlineSmall
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Column {
                    Text(stringResource(R.string.temperature_unit), style = MaterialTheme.typography.bodyLarge)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = tempUnit == "celsius", onClick = {
                            tempUnit = "celsius"
                            sharedPreferences.edit().putString("temp_unit", "celsius").apply()
                        })
                        Text(stringResource(R.string.unit_celsius))
                        Spacer(Modifier.width(16.dp))
                        RadioButton(selected = tempUnit == "fahrenheit", onClick = {
                            tempUnit = "fahrenheit"
                            sharedPreferences.edit().putString("temp_unit", "fahrenheit").apply()
                        })
                        Text(stringResource(R.string.unit_fahrenheit))
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                Column {
                    Text(stringResource(R.string.wind_speed_unit), style = MaterialTheme.typography.bodyLarge)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = windUnit == "kmh", onClick = {
                            windUnit = "kmh"
                            sharedPreferences.edit().putString("wind_unit", "kmh").apply()
                        })
                        Text(stringResource(R.string.unit_kmh))
                        Spacer(Modifier.width(16.dp))
                        RadioButton(selected = windUnit == "mph", onClick = {
                            windUnit = "mph"
                            sharedPreferences.edit().putString("wind_unit", "mph").apply()
                        })
                        Text(stringResource(R.string.unit_mph))
                        Spacer(Modifier.width(16.dp))
                        RadioButton(selected = windUnit == "ms", onClick = {
                            windUnit = "ms"
                            sharedPreferences.edit().putString("wind_unit", "ms").apply()
                        })
                        Text(stringResource(R.string.unit_ms))
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                Column {
                    Text(stringResource(R.string.pressure_unit), style = MaterialTheme.typography.bodyLarge)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = pressureUnit == "hpa", onClick = {
                            pressureUnit = "hpa"
                            sharedPreferences.edit().putString("pressure_unit", "hpa").apply()
                        })
                        Text(stringResource(R.string.unit_hpa))
                        Spacer(Modifier.width(16.dp))
                        RadioButton(selected = pressureUnit == "mmhg", onClick = {
                            pressureUnit = "mmhg"
                            sharedPreferences.edit().putString("pressure_unit", "mmhg").apply()
                        })
                        Text(stringResource(R.string.unit_mmhg))
                    }
                }
            }
        }


        Text(
            text = stringResource(R.string.webview_settings_title),
            style = MaterialTheme.typography.headlineSmall
        )
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                SettingsToggle(
                    title = stringResource(R.string.disable_private_view),
                    subtitle = stringResource(R.string.disable_private_view_subtitle),
                    checked = disablePrivateView,
                    onCheckedChange = {
                        disablePrivateView = it
                        sharedPreferences.edit().putBoolean("disable_private_view", it).apply()
                    }
                )
                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                SettingsToggle(
                    title = stringResource(R.string.open_external_browser),
                    subtitle = stringResource(R.string.open_external_browser_subtitle),
                    checked = openExternalBrowser,
                    onCheckedChange = {
                        openExternalBrowser = it
                        sharedPreferences.edit().putBoolean("open_external_browser", it).apply()
                    }
                )
            }
        }
        Text(
            text = stringResource(R.string.notification_settings_title),
            style = MaterialTheme.typography.headlineSmall
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(stringResource(R.string.temp_threshold_label, tempThreshold))
                Slider(
                    value = tempThreshold.toFloat(),
                    onValueChange = { tempThreshold = it.toInt() },
                    onValueChangeFinished = {
                        sharedPreferences.edit().putInt("notif_temp_threshold", tempThreshold)
                            .apply()
                    },
                    valueRange = 1f..15f,
                    steps = 14
                )

                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                Text(stringResource(R.string.wind_threshold_label, windThreshold))
                Slider(
                    value = windThreshold.toFloat(),
                    onValueChange = { windThreshold = it.toInt() },
                    onValueChangeFinished = {
                        sharedPreferences.edit().putInt("notif_wind_threshold", windThreshold)
                            .apply()
                    },
                    valueRange = 5f..50f,
                    steps = 9
                )

                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                SettingsToggle(
                    title = stringResource(R.string.persistent_notif_title),
                    subtitle = stringResource(R.string.persistent_notif_subtitle),
                    checked = persistentNotif,
                    onCheckedChange = {
                        persistentNotif = it
                        sharedPreferences.edit().putBoolean("persistent_notif", it).apply()
                        val serviceIntent = Intent(context, WeatherForegroundService::class.java)
                        if (it) {
                            context.startForegroundService(serviceIntent)
                        } else {
                            context.stopService(serviceIntent)
                        }
                    }
                )
            }
        }

        Text(
            text = stringResource(R.string.feedback_title),
            style = MaterialTheme.typography.headlineSmall
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = {
                        val intent = Intent(Intent.ACTION_SENDTO).apply {
                            data = Uri.parse("mailto:")
                            putExtra(Intent.EXTRA_EMAIL, arrayOf("9ndlzdct@anonaddy.me"))
                            putExtra(Intent.EXTRA_SUBJECT, feedbackSubject)
                        }
                        try {
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            Toast.makeText(context, "No email app found", Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(stringResource(R.string.feedback_btn))
                }
            }
        }

        Text(
            text = stringResource(R.string.backup_restore_title),
            style = MaterialTheme.typography.headlineSmall
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = { exportLauncher.launch("geoweather_backup.json") },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(stringResource(R.string.export_locations))
                }
                
                OutlinedButton(
                    onClick = { importLauncher.launch(arrayOf("application/json")) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(stringResource(R.string.import_locations))
                }
            }
        }
        
        Spacer(modifier = Modifier.height(32.dp))
    }
}

@Composable
fun SettingsToggle(
    title: String,
    subtitle: String? = null,
    checked: Boolean,
    enabled: Boolean = true,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (subtitle != null) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Switch(
            checked = checked,
            enabled = enabled,
            onCheckedChange = onCheckedChange
        )
    }
}

// Helper extension function for SharedPreferences
@SuppressLint("ApplySharedPref")
private inline fun SharedPreferences.editApply(block: SharedPreferences.Editor.() -> Unit) {
    edit().apply(block).apply()
}

