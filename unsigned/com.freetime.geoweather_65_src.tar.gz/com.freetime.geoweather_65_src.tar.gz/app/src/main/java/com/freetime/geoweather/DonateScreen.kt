package com.freetime.geoweather

import android.app.Activity
import android.content.Intent
import android.view.View
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView

import com.freetime.sdk.FreetimePay
import com.freetime.sdk.PaymentRequest
import com.freetime.sdk.PaymentResult
import com.freetime.sdk.PromotionView

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DonateScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val activity = context as? Activity
    var showAmountDialog by remember { mutableStateOf(false) }

    if (showAmountDialog && activity != null) {
        DonationAmountDialog(
            onDismiss = { showAmountDialog = false },
            onAmountSelected = { amount, currency ->
                showAmountDialog = false
                val request = PaymentRequest(
                    amount = amount,
                    currency = currency,
                    description = "GeoWeather Donation"
                )
                try {
                    GeoWeatherApp.freetimePay.showPaymentSheet(activity, request) { result ->
                        when (result) {
                            is PaymentResult.Success -> {
                                Toast.makeText(context, "Thank you for your donation!", Toast.LENGTH_LONG).show()
                            }
                            is PaymentResult.Error -> {
                                Toast.makeText(context, "Error: ${result.message}", Toast.LENGTH_LONG).show()
                            }
                            PaymentResult.Cancelled -> {}
                        }
                    }
                } catch (e: Exception) {
                    Toast.makeText(context, "Error starting payment", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.donate_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back_nav_desc))
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            AndroidView(
                factory = { ctx ->
                    try {
                        PromotionView(ctx).apply {
                            loadPromotion(GeoWeatherApp.freetimePay.config)
                        }
                    } catch (e: Exception) {
                        View(ctx) // Fallback to empty view on crash
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = stringResource(R.string.support_development),
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = stringResource(R.string.select_option_msg),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.5f)
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = stringResource(R.string.about_developer_title),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = stringResource(R.string.about_developer_text),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = stringResource(R.string.donation_mission_title),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = stringResource(R.string.donation_mission_text),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Text(
                text = stringResource(R.string.cash_label),
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.align(Alignment.Start).padding(top = 8.dp)
            )

            DonateButton(text = stringResource(R.string.DonViaGHSponsors)) {
                val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://github.com/sponsors/FreetimeMaker"))
                context.startActivity(intent)
            }

            Text(
                text = stringResource(R.string.crypto_label),
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.align(Alignment.Start).padding(top = 8.dp)
            )

            DonateButton(text = stringResource(R.string.DonViaFMSDK)) {
                showAmountDialog = true
            }

            DonateButton(text = stringResource(R.string.show_wallet_addresses)) {
                context.startActivity(Intent(context, WalletAddressActivity::class.java))
            }

            DonateButton(text = stringResource(R.string.don_nowpayments_via)) {
                val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://nowpayments.io/donation/GeoWeather"))
                context.startActivity(intent)
            }

            DonateButton(text = stringResource(R.string.DonViaOxaPay)) {
                val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://pay.oxapay.com/13038067"))
                context.startActivity(intent)
            }

            DonateButton(text = stringResource(R.string.DonViaBTC)) {
                val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://ncwallet.net/pay/60misly"))
                context.startActivity(intent)
            }

            DonateButton(text = stringResource(R.string.DonViaETH)) {
                val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://ncwallet.net/pay/86fremd"))
                context.startActivity(intent)
            }

            DonateButton(text = stringResource(R.string.DonViaUSDT)) {
                val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://ncwallet.net/pay/19tacit"))
                context.startActivity(intent)
            }

            DonateButton(text = stringResource(R.string.DonViaUSDC)) {
                val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://ncwallet.net/pay/15snog"))
                context.startActivity(intent)
            }

            DonateButton(text = stringResource(R.string.DonViaSHIB)) {
                val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://ncwallet.net/pay/18spile"))
                context.startActivity(intent)
            }

            DonateButton(text = stringResource(R.string.DonViaDOGE)) {
                val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://ncwallet.net/pay/30allie"))
                context.startActivity(intent)
            }

            DonateButton(text = stringResource(R.string.DonateViaTRON)) {
                val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://ncwallet.net/pay/15gown"))
                context.startActivity(intent)
            }

            DonateButton(text = stringResource(R.string.DonViaLTC)) {
                val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://ncwallet.net/pay/77pudgy"))
                context.startActivity(intent)
            }

            DonateButton(text = stringResource(R.string.DonViaBNB)) {
                val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://ncwallet.net/pay/02hanch"))
                context.startActivity(intent)
            }

            DonateButton(text = stringResource(R.string.DonViaPEPE)) {
                val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://ncwallet.net/pay/73enow"))
                context.startActivity(intent)
            }

            DonateButton(text = stringResource(R.string.DonViaSOL)) {
                val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://ncwallet.net/pay/54fled"))
                context.startActivity(intent)
            }

            DonateButton(text = stringResource(R.string.DonViaDAI)) {
                val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://ncwallet.net/pay/27thio"))
                context.startActivity(intent)
            }

            DonateButton(text = stringResource(R.string.DonViaTON)) {
                val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://ncwallet.net/pay/22frisk"))
                context.startActivity(intent)
            }

            DonateButton(text = stringResource(R.string.DonViaPOL)) {
                val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://ncwallet.net/pay/23patas"))
                context.startActivity(intent)
            }

            DonateButton(text = stringResource(R.string.DonViaOptimism)) {
                val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://ncwallet.net/pay/77salvy"))
                context.startActivity(intent)
            }

            DonateButton(text = stringResource(R.string.DonViaARB)) {
                val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://ncwallet.net/pay/80arui"))
                context.startActivity(intent)
            }

            Spacer(Modifier.height(16.dp))

            FilledTonalButton(
                onClick = { context.startActivity(Intent(context, DonatorActivity::class.java)) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(stringResource(R.string.ViewSup))
            }
        }
    }
}

@Composable
fun DonateButton(text: String, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(text)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DonationAmountDialog(
    onDismiss: () -> Unit,
    onAmountSelected: (Double, String) -> Unit
) {
    val predefinedAmounts = listOf(2.0, 5.0, 10.0, 25.0, 50.0)
    val fiatCurrencies = listOf("USD", "EUR", "GBP", "JPY", "AUD", "CAD", "CHF", "CNY", "HKD", "NZD")
    val cryptoCurrencies = remember {
        GeoWeatherApp.freetimePay.getAvailableProviders().map { provider ->
            if (provider.name.contains("(") && provider.name.contains(")")) {
                provider.name.substringAfterLast("(").substringBefore(")")
            } else {
                provider.name
            }
        }.filter { it.length <= 5 && !it.contains("/") && !it.contains(" ") && it != "Mock" }.distinct()
    }
    val currencies = fiatCurrencies + cryptoCurrencies

    var selectedCurrency by remember { mutableStateOf("USD") }
    var customAmount by remember { mutableStateOf("") }
    var selectedPredefined by remember { mutableStateOf<Double?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var expanded by remember { mutableStateOf(false) }

    val invalidAmountMsg = stringResource(R.string.invalid_amount_msg)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.select_donation_amount)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Text(stringResource(R.string.billing_options_title), style = MaterialTheme.typography.labelMedium)

                ExposedDropdownMenuBox(
                    expanded = expanded,
                    onExpandedChange = { expanded = !expanded }
                ) {
                    OutlinedTextField(
                        value = selectedCurrency,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text(stringResource(R.string.currency_label)) },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                        modifier = Modifier.menuAnchor(ExposedDropdownMenuAnchorType.PrimaryNotEditable, true).fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false }
                    ) {
                        currencies.forEach { currency ->
                            DropdownMenuItem(
                                text = { Text(currency) },
                                onClick = {
                                    selectedCurrency = currency
                                    expanded = false
                                }
                            )
                        }
                    }
                }
                
                // Predefined amounts grid
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    val chunks = predefinedAmounts.chunked(3)
                    chunks.forEach { chunk ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            chunk.forEach { amount ->
                                FilterChip(
                                    selected = selectedPredefined == amount && customAmount.isEmpty(),
                                    onClick = {
                                        selectedPredefined = amount
                                        customAmount = ""
                                        error = null
                                    },
                                    label = { 
                                        val symbol = when(selectedCurrency) {
                                            "USD" -> "$"
                                            "EUR" -> "€"
                                            "GBP" -> "£"
                                            "JPY" -> "¥"
                                            "CNY" -> "¥"
                                            else -> null
                                        }
                                        if (symbol != null) {
                                            Text("$symbol${amount.toInt()}")
                                        } else {
                                            Text("${amount.toInt()} $selectedCurrency")
                                        }
                                    },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            // Fill empty slots in the row if any
                            repeat(3 - chunk.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                }

                HorizontalDivider()

                OutlinedTextField(
                    value = customAmount,
                    onValueChange = {
                        customAmount = it
                        selectedPredefined = null
                        error = null
                    },
                    label = { Text(stringResource(R.string.custom_amount_label)) },
                    placeholder = { 
                        Text(stringResource(R.string.amount_in_currency_hint, selectedCurrency)) 
                    },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    isError = error != null,
                    supportingText = { error?.let { Text(it) } }
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val finalAmount = if (customAmount.isNotEmpty()) {
                        customAmount.toDoubleOrNull()
                    } else {
                        selectedPredefined
                    }

                    if (finalAmount != null && finalAmount > 0) {
                        onAmountSelected(finalAmount, selectedCurrency)
                    } else {
                        error = invalidAmountMsg
                    }
                }
            ) {
                Text(stringResource(R.string.donate_btn))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.cancel_btn))
            }
        }
    )
}
